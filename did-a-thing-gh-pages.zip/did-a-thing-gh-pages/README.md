# [Did a thing](https://le717.github.io/did-a-thing/)

> Congratulate someone when they did a thing!

Made for fun in an afternoon. Background audio from [youtube.com/watch?v=wDajqW561KM](https://www.youtube.com/watch?v=wDajqW561KM).

## License

[MIT](LICENSE)
